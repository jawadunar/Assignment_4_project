def main():
    """Prints the first 20 even numbers."""
    for i in range(20):
        print(i * 2, end=" ")
    print()  # New line after printing all numbers

if __name__ == "__main__":
    main()

