def get_name():
    return "Sophia"  # You can change this to your name

# There is no need to edit code beyond this point

def main():
    name = get_name()  # get_name() will return a string which we store to the 'name' variable here
    print("Howdy", name, "! 🤠")

if __name__ == '__main__':
    main()

