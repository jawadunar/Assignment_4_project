def main():
    favorite_animal = input("What's your favorite animal? ")
    print(f"My favorite animal is also {favorite_animal}!")

if __name__ == '__main__':
    main()
    

